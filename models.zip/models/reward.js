var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var menuListing = require('./menuListing');

var schema = new Schema({
    itemName: {
      type: Schema.ObjectId,
      ref: 'menuListing'
       },
     startdate:: {
       type: Date,
        required: true
       },
      enddate:: {
         type: Date,
          required: true
         },
      quantity:: {
        type: String,
         required: true
        },


});


module.exports = mongoose.model('reward', schema);
